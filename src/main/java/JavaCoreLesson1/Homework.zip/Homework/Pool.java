package JavaCoreLesson1.Homework;

public class Pool extends Barrier{

    public Pool(int size, int energyLose) {
        super(size, energyLose);
    }
}

package JavaCoreLesson1.Homework;

public class Track extends Barrier{

    public Track(int size, int energyLose) {
        super(size, energyLose);
    }
}

package JavaCoreLesson1.Homework;

public class Wall extends Barrier {

    public Wall(int size, int energyLose) {
        super(size, energyLose);
    }
}
